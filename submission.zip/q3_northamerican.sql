SELECT Id,ShipCountry, CASE ShipCountry
WHEN 'USA' THEN 'NorthAmerica'
WHEN 'Mexico' THEN 'NorthAmerica'
WHEN 'Canada' THEN 'NorthAmerica'
ELSE 'OtherPlace' end as 'Country'
FROM 'Order'
ORDER BY 'Id' ASC
LIMIT 20 OFFSET 5197;