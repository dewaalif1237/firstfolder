SELECT CategoryName
     , COUNT(*) AS JumlahProduk
     , ROUND(AVG(UnitPrice), 2) AS HargaRataRataProduk
     , MIN(UnitPrice) AS MinimumHargaProduk
     , MAX(UnitPrice) AS MaximumHargaPorduk
     , SUM(UnitsOnOrder) AS TotalUnitsOnOrder
FROM Product INNER JOIN Category on CategoryId = Category.Id
GROUP BY CategoryId
HAVING JumlahProduk > 10
ORDER BY CategoryId;